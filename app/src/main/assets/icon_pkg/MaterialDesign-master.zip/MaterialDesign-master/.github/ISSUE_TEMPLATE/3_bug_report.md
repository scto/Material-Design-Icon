---
name: Report a Bug 🐛
about: Report an issue with an icon.
title: ''
labels: Bug

---

<!-- 
>> Make sure you searched opened issues! <<

If an icon is on the site it does not mean it has
been released. https://materialdesignicons.com/history
-->
