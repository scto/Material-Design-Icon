---
name: Suggest an Icon Alias 🔃
about: Make it easier to find the icons you need by suggesting alternative names.
title: ''
labels: Alias

---

<!-- 
>> Make sure you searched opened issues! <<

If an icon is on the site it does not mean it has
been released. https://materialdesignicons.com/history
-->
