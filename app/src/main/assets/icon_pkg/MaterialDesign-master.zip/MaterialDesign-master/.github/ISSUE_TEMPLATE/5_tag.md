---
name: Suggest a Tag 🏷
about: Suggest a tag for an existing icon or a new tag entirely.
title: ''
labels: Tag

---

<!-- 
>> Make sure you searched opened issues! <<

Tags work like categories for icons. Multiple tags
may apply for a single icon.
-->
