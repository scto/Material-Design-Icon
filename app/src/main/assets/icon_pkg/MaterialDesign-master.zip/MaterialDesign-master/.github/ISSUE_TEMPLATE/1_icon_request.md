---
name: Request an Icon 💡
about: Request an icon for the team to add
title: ''
labels: Icon Request

---

<!--
We are no longer accepting brand icons. Learn more: http://dev.materialdesignicons.com/roadmap/brand-icons
-->

I have:

- [ ] [Searched all issues](https://github.com/Templarian/MaterialDesign/issues) to make sure there isn't a request for this icon.
- [ ] [Searched the current library](https://materialdesignicons.com/) to make sure the icon doesn't exist.
- [ ] Only requested a single icon (or a few near-identical ones) in this issue. 

## Usage

Provide some context of how your icon could be used.

## Examples

Include any example images so we know what the icon should look like.

