---
name: Contribute an Icon ➕
about: Get your icon into MDI. 
title: ''
labels: Icon Request, Contribution

---

<!--
We are no longer accepting brand icons. Learn more: http://dev.materialdesignicons.com/roadmap/brand-icons
-->

I have:

- [ ] [Searched the current library](https://materialdesignicons.com/) to make sure the icon doesn't exist.
- [ ] Searched open issues to make sure there isn't a request for this icon.
- [ ] Followed the [material guidelines](https://material.io/design/iconography/system-icons.html).


## Preview

Paste a preview of your icon here. You can generate one using our [preview generator](http://dev.materialdesignicons.com/contribute/github).

## Zip Download

Drag or paste a zip folder containing your icon as a minimal SVG file. We just need the SVG tag with the viewbox and a single path element.
